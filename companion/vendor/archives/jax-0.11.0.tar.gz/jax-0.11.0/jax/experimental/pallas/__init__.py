# Copyright 2023 The JAX Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Module for Pallas, a JAX extension for custom kernels.

See the Pallas documentation at
https://docs.jax.dev/en/latest/pallas/index.html.
"""

from jax._src import core as _jax_core
from jax._src.pallas.core import BlockDim as BlockDim
from jax._src.pallas.core import Blocked as Blocked
from jax._src.pallas.core import BlockSpec as BlockSpec
from jax._src.pallas.core import BoundedSlice as BoundedSlice
from jax._src.pallas.core import Buffered as Buffered
from jax._src.pallas.core import CompilerParams as CompilerParams
from jax._src.pallas.core import core_map as core_map
from jax._src.pallas.core import CostEstimate as CostEstimate
from jax._src.pallas.core import debug_check as debug_check
from jax._src.pallas.core import debug_checks_enabled as _deprecated_debug_checks_enabled
from jax._src.pallas.core import Element as Element
from jax._src.pallas.core import enable_debug_checks as enable_debug_checks
from jax._src.pallas.core import enable_poison_buffers as enable_poison_buffers
from jax._src.pallas.core import GridSpec as GridSpec
from jax._src.pallas.core import Indirect as Indirect
from jax._src.pallas.core import lower_as_mlir as lower_as_mlir
from jax._src.pallas.core import MemoryRef as MemoryRef
from jax._src.pallas.core import MemorySpace as MemorySpace
from jax._src.pallas.core import no_block_spec as no_block_spec
from jax._src.pallas.core import pallas_export_experimental as pallas_export_experimental
from jax._src.pallas.core import RevisitMode as RevisitMode
from jax._src.pallas.core import semaphore as semaphore
from jax._src.pallas.core import Squeezed as Squeezed
from jax._src.pallas.core import squeezed as squeezed
from jax._src.pallas.cost_estimate import estimate_cost as estimate_cost
from jax._src.pallas.helpers import empty as empty
from jax._src.pallas.helpers import empty_like as empty_like
from jax._src.pallas.helpers import empty_ref_like as empty_ref_like
from jax._src.pallas.helpers import kernel as kernel
from jax._src.pallas.helpers import loop as loop
from jax._src.pallas.helpers import select_ref as select_ref
from jax._src.pallas.helpers import when as when
from jax._src.pallas.helpers import with_scoped as with_scoped
from jax._src.pallas.pallas_call import pallas_call as pallas_call
from jax._src.pallas.pallas_call import pallas_call_p as pallas_call_p
from jax._src.pallas.primitives import debug_print as debug_print
from jax._src.pallas.primitives import delay as delay
from jax._src.pallas.primitives import DeviceIdType as DeviceIdType
from jax._src.pallas.primitives import dot as _deprecated_dot
from jax._src.pallas.primitives import get_global as get_global
from jax._src.pallas.primitives import multiple_of as multiple_of
from jax._src.pallas.primitives import num_programs as num_programs
from jax._src.pallas.primitives import program_id as program_id
from jax._src.pallas.primitives import reciprocal as reciprocal
from jax._src.pallas.primitives import run_scoped as run_scoped
from jax._src.pallas.primitives import semaphore_read as semaphore_read
from jax._src.pallas.primitives import semaphore_signal as semaphore_signal
from jax._src.pallas.primitives import semaphore_wait as semaphore_wait
from jax._src.pallas.utils import align_to as align_to
from jax._src.pallas.utils import cdiv as cdiv
from jax._src.pallas.utils import next_power_of_2 as next_power_of_2
from jax._src.pallas.utils import strides_from_shape as strides_from_shape
from jax._src.state.discharge import run_state as run_state
from jax._src.state.indexing import ds as ds
from jax._src.state.indexing import dslice as dslice
from jax._src.state.indexing import Slice as Slice
from jax._src.state.primitives import broadcast_to as broadcast_to


ANY = MemorySpace.ANY
HOST = _jax_core.MemorySpace.Host

_deprecations = {
    # Added June 4, 2026
    "dot": (
        (
            "jax.experimental.pallas.dot was moved to"
            " jax.experimental.pallas.triton. Accessing it via"
            " jax.experimental.pallas is deprecated. You can use jax.numpy.dot,"
            " jax.numpy.einsum or the @ operator instead in a TPU or MGPU"
            " kernel."
        ),
        _deprecated_dot,
    ),
    # Added May 15, 2026
    "debug_checks_enabled": (
        (
            "jax.experimental.pallas.debug_checks_enabled is deprecated, "
            "use pl.enable_debug_checks.value instead."
        ),
        _deprecated_debug_checks_enabled,
    ),
}

import typing
if typing.TYPE_CHECKING:
  debug_checks_enabled = _deprecated_debug_checks_enabled
  dot = _deprecated_dot
else:
  from jax._src.deprecations import deprecation_getattr as _deprecation_getattr
  __getattr__ = _deprecation_getattr(__name__, _deprecations)
  del _deprecation_getattr
del typing
del _jax_core
